# +=
a = 10
sum += a
sum = sum + a

a++ # ERROR

# 同理，*=, /=, %=, **=