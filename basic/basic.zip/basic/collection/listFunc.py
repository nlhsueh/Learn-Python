t = [1,2,3]
len(t)	
max(t), min(t)
[1, 2, 3] + [4, 5, 6]	
['Hello!'] * 3	
3 in [1, 2, 3]	 

for x in [1, 2, 3]: 
   print (x)	

t = [1,2,3]
del t[1]
t