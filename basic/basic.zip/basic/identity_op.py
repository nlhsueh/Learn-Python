a = [1,2,3]
b = [1,2,3]
a is b
>> False
a is not b
>> True

c = a
c is a
>> True
