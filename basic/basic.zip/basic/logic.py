# and
if (isPrime and isSmall):
    print ()
# or 
if (isStudent or isKid):
    print ()
# not
if not(isStudent or isKid):
    print ()

# 比較運算元
== 等於
>= 大於等於
!= 不等於

# 成員（membership）: in, not in
x = 100; grade = [12, 45, 90]
x in grade
>> False
x not in grade
>> True