# basic operations
10 + 4          # add, 14
10 - 4          # subtract, 6
10 * 4          # multiply, 40
10 ** 4         # exponent, 10000
5 % 4           # modulo, 1
10 / 4          # divide, 2.5
10 // 4         # 2
10 / float(4)   # divide, 2.5
round(5.5) 		# 四捨五入, 6
round(5.49)		# 5
round(5.49, 1)	# 5.5

import math
math.ceil(10.1) # 11

import random
random.random()
random.sample(range(100), 5)